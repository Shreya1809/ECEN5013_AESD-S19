var dir_b3ce0307ce72ed9eed1b8e4daddb0525 =
[
    [ "BubbleSort", "dir_edfd5a5b0a3e13b73b9c061fb0df3719.html", "dir_edfd5a5b0a3e13b73b9c061fb0df3719" ],
    [ "MergeSort", "dir_e52b936e84041708799704bdf8f4ff29.html", "dir_e52b936e84041708799704bdf8f4ff29" ]
];