var dir_cb8ae0912c65b4dbc84ea9d93cd33be0 =
[
    [ "IPC", "dir_17106042d5f4b0cbc4d7616649348fcf.html", "dir_17106042d5f4b0cbc4d7616649348fcf" ],
    [ "pthreads", "dir_6c2ad54e7737d8f01f892fbfa7d72b34.html", "dir_6c2ad54e7737d8f01f892fbfa7d72b34" ]
];