var dir_17106042d5f4b0cbc4d7616649348fcf =
[
    [ "pipes", "dir_c5194d48db9ba79619dfa73959cffb8c.html", "dir_c5194d48db9ba79619dfa73959cffb8c" ],
    [ "posix_q", "dir_eb6ab8a6b83e9877b2514e040a9753e3.html", "dir_eb6ab8a6b83e9877b2514e040a9753e3" ],
    [ "shared_mem", "dir_e31ac2f6b9fc455fff5baa8e2a76521b.html", "dir_e31ac2f6b9fc455fff5baa8e2a76521b" ],
    [ "sockets", "dir_50f0c955da9152cb9d462899d34c4303.html", "dir_50f0c955da9152cb9d462899d34c4303" ]
];