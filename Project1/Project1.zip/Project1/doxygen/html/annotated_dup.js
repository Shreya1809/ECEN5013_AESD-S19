var annotated_dup =
[
    [ "CheckIntegerRange", "structCheckIntegerRange.html", "structCheckIntegerRange" ],
    [ "CheckIntegerSet", "structCheckIntegerSet.html", "structCheckIntegerSet" ],
    [ "CheckMemoryData", "structCheckMemoryData.html", "structCheckMemoryData" ],
    [ "CheckParameterEvent", "structCheckParameterEvent.html", "structCheckParameterEvent" ],
    [ "CMUnitTest", "structCMUnitTest.html", "structCMUnitTest" ],
    [ "CMUnitTestState", "structCMUnitTestState.html", "structCMUnitTestState" ],
    [ "GroupTest", "structGroupTest.html", "structGroupTest" ],
    [ "i2c_struct_t", "structi2c__struct__t.html", "structi2c__struct__t" ],
    [ "ListNode", "structListNode.html", "structListNode" ],
    [ "log_struct_t", "structlog__struct__t.html", "structlog__struct__t" ],
    [ "loggerTask_param", "structloggerTask__param.html", "structloggerTask__param" ],
    [ "main_struct_t", "structmain__struct__t.html", "structmain__struct__t" ],
    [ "MallocBlockInfo", "structMallocBlockInfo.html", "structMallocBlockInfo" ],
    [ "SourceLocation", "structSourceLocation.html", "structSourceLocation" ],
    [ "SymbolMapValue", "structSymbolMapValue.html", "structSymbolMapValue" ],
    [ "SymbolValue", "structSymbolValue.html", "structSymbolValue" ],
    [ "TestState", "structTestState.html", "structTestState" ],
    [ "UnitTest", "structUnitTest.html", "structUnitTest" ],
    [ "ValuePointer", "unionValuePointer.html", "unionValuePointer" ]
];