var structCheckMemoryData =
[
    [ "event", "structCheckMemoryData.html#afa102f599993f28924b9f73cf9b45990", null ],
    [ "memory", "structCheckMemoryData.html#aac7288cc682bfa7917c6258c56aeb723", null ],
    [ "size", "structCheckMemoryData.html#a0015b301a15e7b148e95aa1d6f51cb11", null ]
];