var structmain__struct__t =
[
    [ "msg", "structmain__struct__t.html#ad4138206cfaf1bf5c314b872cb7765ef", null ],
    [ "srcModuleID", "structmain__struct__t.html#a4c52ba181aa633dd772305cfc13c3fdf", null ],
    [ "status", "structmain__struct__t.html#a7621e814158ca8929253263df4cba606", null ]
];