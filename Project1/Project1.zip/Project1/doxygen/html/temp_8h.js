var temp_8h =
[
    [ "GET_TEMP_CELCIUS", "temp_8h.html#ac5a5f868e354da2dc6b6369257e456e7", null ],
    [ "GET_TEMP_FARENHEIT", "temp_8h.html#a2ff7394438b7be3da486032f5dbf1441", null ],
    [ "GET_TEMP_KELVIN", "temp_8h.html#ab00bf732d7ff2a924fcdb1ee2d67e1e4", null ],
    [ "temp_unit", "temp_8h.html#ac8d2c3bb7b53a565afc5303dbd86af48", [
      [ "CELCIUS", "temp_8h.html#ac8d2c3bb7b53a565afc5303dbd86af48a6600ab5b3b178055238cfb794ca39499", null ],
      [ "KELVIN", "temp_8h.html#ac8d2c3bb7b53a565afc5303dbd86af48a1ee6e694f8ea36c8ed7c0e5c76439b50", null ],
      [ "FARENHEIT", "temp_8h.html#ac8d2c3bb7b53a565afc5303dbd86af48a137783d5482942f5b8a51d3ff5322f0c", null ]
    ] ],
    [ "getTemperature", "temp_8h.html#ad278c9dd0785311834fbdd25e9ccb08e", null ],
    [ "kill_temp_thread", "temp_8h.html#a6c6e8e13fb2ba7d141945e64b5b693cc", null ],
    [ "RemoteThresholdValues", "temp_8h.html#a7beb226afb19a57861973866ecaf5338", null ],
    [ "temp_task", "temp_8h.html#a9367e0b2320b0dd727163e557a9791d6", null ],
    [ "TMP102_setTempThreshold", "temp_8h.html#a0584aa99c4703588749b140587d1724a", null ]
];