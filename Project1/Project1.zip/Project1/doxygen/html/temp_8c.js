var temp_8c =
[
    [ "getTemperature", "temp_8c.html#ad278c9dd0785311834fbdd25e9ccb08e", null ],
    [ "kill_temp_thread", "temp_8c.html#a6c6e8e13fb2ba7d141945e64b5b693cc", null ],
    [ "RemoteThresholdValues", "temp_8c.html#a7beb226afb19a57861973866ecaf5338", null ],
    [ "temp_task", "temp_8c.html#a9367e0b2320b0dd727163e557a9791d6", null ],
    [ "TMP102_setTempThreshold", "temp_8c.html#a0584aa99c4703588749b140587d1724a", null ],
    [ "t_count", "temp_8c.html#a4e9707ca4dbcd2ddd6d14657f2e12700", null ],
    [ "temp_var_lock", "temp_8c.html#a8b494c3bbbc61f0f14ab42c39ecd22f3", null ]
];