var structloggerTask__param =
[
    [ "filename", "structloggerTask__param.html#aea04d7d9c5f62c2986470ba7e8028a89", null ],
    [ "loglevel", "structloggerTask__param.html#a00b4463ec089cbba3cfb67bfa224b777", null ]
];