var dir_837fb246598b7aa7600596dc8d79efc1 =
[
    [ "client.c", "client_8c.html", "client_8c" ]
];