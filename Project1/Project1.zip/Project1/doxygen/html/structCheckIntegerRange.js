var structCheckIntegerRange =
[
    [ "event", "structCheckIntegerRange.html#a143da2245bf12c28ebc8521e8925d98c", null ],
    [ "maximum", "structCheckIntegerRange.html#a61124c5298a3b1542422125446ef3db1", null ],
    [ "minimum", "structCheckIntegerRange.html#afcc266d34a957220d9d2a202c67290ff", null ]
];