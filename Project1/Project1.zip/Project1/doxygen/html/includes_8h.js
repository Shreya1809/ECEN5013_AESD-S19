var includes_8h =
[
    [ "PORT", "includes_8h.html#a614217d263be1fb1a5f76e2ff7be19a2", null ],
    [ "light_sem", "includes_8h.html#a38e04ca35bfd8a72033b6b6371cb8864", null ],
    [ "light_thread_sem", "includes_8h.html#ab36e03a82a65c21a398d1fb697fc0c20", null ],
    [ "logger_thread_sem", "includes_8h.html#a4e613ae6cb0a00a06601cdb221393efa", null ],
    [ "socket_thread_sem", "includes_8h.html#a9f31099ed3b6b3fa0c59f5d1205ddcd5", null ],
    [ "temp_sem", "includes_8h.html#ade323b172605e654343b53e67fd86a52", null ],
    [ "temp_thread_sem", "includes_8h.html#afa7ff2b9f6946b56b509a50653b517c1", null ]
];