var structListNode =
[
    [ "next", "structListNode.html#ac7af9e18e0586f13d59a52b3501ac4ca", null ],
    [ "prev", "structListNode.html#ac29aefb7627ded4e29dcb96b7a47f3f2", null ],
    [ "refcount", "structListNode.html#a4b3cd4e8c0dab91f5a07978b50d63b38", null ],
    [ "value", "structListNode.html#a048e935049ce14b34caab57c975a9ace", null ]
];