var myI2C_8h =
[
    [ "i2c_struct_t", "structi2c__struct__t.html", "structi2c__struct__t" ],
    [ "I2C_BUS", "myI2C_8h.html#a357ae664eb5f3c937443339e9b568c51", null ],
    [ "I2C_close", "myI2C_8h.html#ae8decee1cd7906785e6ce389d71e14c0", null ],
    [ "I2C_init", "myI2C_8h.html#a0799af3d3a75e0597b805dedfecc9d07", null ],
    [ "I2C_read_byte", "myI2C_8h.html#a6fdfce2ee87545c93df820fafd913370", null ],
    [ "I2C_read_bytes", "myI2C_8h.html#a5d22d3baf97a7fbff1036bee6c34b64e", null ],
    [ "I2C_set_slave", "myI2C_8h.html#a0b94ae8a4cd4577a177959a15fe7a837", null ],
    [ "I2C_write_byte", "myI2C_8h.html#a239ee2fef128c26fdc70926af40b8831", null ],
    [ "I2C_write_byte_data", "myI2C_8h.html#a951696b402a493dde4120b49a709a9fe", null ],
    [ "I2C_write_word", "myI2C_8h.html#ad25819b7ac00db28d3f446105592306f", null ],
    [ "i2c_handler", "myI2C_8h.html#a4e46ab3a667671303a97f4f464dda05a", null ]
];