var unionValuePointer =
[
    [ "pointer", "unionValuePointer.html#a90d9bff0d538cfab7b46b9b496c36801", null ],
    [ "value", "unionValuePointer.html#ad8994d8ea772e4033e1017ecb7b7b251", null ],
    [ "x", "unionValuePointer.html#a088c1a29a21d4bb2d6529c63fb08dff3", null ]
];