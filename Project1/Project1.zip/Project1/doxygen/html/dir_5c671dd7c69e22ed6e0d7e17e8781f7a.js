var dir_5c671dd7c69e22ed6e0d7e17e8781f7a =
[
    [ "HW1", "dir_5361d95ff80bedd4a88c09a27b28b4a3.html", "dir_5361d95ff80bedd4a88c09a27b28b4a3" ],
    [ "HW2", "dir_c2a8f48daad66c873ef970acbb1c538f.html", "dir_c2a8f48daad66c873ef970acbb1c538f" ],
    [ "HW3", "dir_c8749c6ecaceac5372f481f2aac5f693.html", "dir_c8749c6ecaceac5372f481f2aac5f693" ],
    [ "HW4", "dir_cb8ae0912c65b4dbc84ea9d93cd33be0.html", "dir_cb8ae0912c65b4dbc84ea9d93cd33be0" ]
];