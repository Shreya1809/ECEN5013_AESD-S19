var lightSensor_8c =
[
    [ "APDS9301_CheckInt", "lightSensor_8c.html#a4ff1625996e8f1cebf5041777c653964", null ],
    [ "APDS9301_getCh0", "lightSensor_8c.html#ad14a314497f8bf3ce13762a87064bad7", null ],
    [ "APDS9301_getCh1", "lightSensor_8c.html#a913f86bed7075b949472dc93f6f52ca2", null ],
    [ "APDS9301_getlight", "lightSensor_8c.html#ae12804ca44a2f58617bd467c8633553e", null ],
    [ "APDS9301_intClear", "lightSensor_8c.html#a2c4c5c895ba901f884f473651bd3afdc", null ],
    [ "APDS9301_interruptCTRLreg", "lightSensor_8c.html#a59400c5e7bbb4752c3fc2ce6a27f47eb", null ],
    [ "APDS9301_powerup", "lightSensor_8c.html#a790e79354d79d996d39d97e3c0750f81", null ],
    [ "APDS9301_readCTRLreg", "lightSensor_8c.html#a2b9865a81efbf475c33b9348b24fcf7e", null ],
    [ "APDS9301_readIDreg", "lightSensor_8c.html#a960a4cfc5ff042a3fc995a201eb83916", null ],
    [ "APDS9301_readTHRESH_highhigh", "lightSensor_8c.html#a820e46ef315ed974ba7143bff769d12d", null ],
    [ "APDS9301_readTHRESH_highlow", "lightSensor_8c.html#a916087564af4e500cd44af4217422990", null ],
    [ "APDS9301_readTHRESH_lowhigh", "lightSensor_8c.html#ab007d3bff77582d8fc9939fac33caaed", null ],
    [ "APDS9301_readTHRESH_lowlow", "lightSensor_8c.html#a0ae11df36762fe2f91009e48937d17d7", null ],
    [ "APDS9301_setAllDefault", "lightSensor_8c.html#a8aa4cf1866fd0f410dfa714fae4828d3", null ],
    [ "APDS9301_setTiming_gain", "lightSensor_8c.html#a6d4e3519fb0b0a6de99323d272831fbf", null ],
    [ "APDS9301_setTiming_integ", "lightSensor_8c.html#a8db9045d0df240c23ef622c93a4349ff", null ],
    [ "APDS9301_writeCMDreg", "lightSensor_8c.html#adaf832bbb1ee2551672b59b171913212", null ],
    [ "APDS9301_writeTHRESH_highlow", "lightSensor_8c.html#a12baf424983442a616b5fb4fe161ede6", null ],
    [ "APDS9301_writeTHRESH_lowlow", "lightSensor_8c.html#ac3ee1a2ef65b70265a65944dfa8aeb7f", null ]
];