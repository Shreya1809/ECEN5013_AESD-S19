var structCheckIntegerSet =
[
    [ "event", "structCheckIntegerSet.html#a7153dfb1ec04c0fcacfeb2d60321d4fd", null ],
    [ "set", "structCheckIntegerSet.html#a9bb5e12093c709bc42788033506c1c2a", null ],
    [ "size_of_set", "structCheckIntegerSet.html#a82dbcbeea43de48060c86d89c6ccc444", null ]
];