var structMallocBlockInfo =
[
    [ "allocated_size", "structMallocBlockInfo.html#a103783e0ba99bc5360f69c3b30a39048", null ],
    [ "block", "structMallocBlockInfo.html#aaca8b34ff6f79f4454bba197a21a52e7", null ],
    [ "location", "structMallocBlockInfo.html#af1a66bb07ef7e53441b7fca1c6c61906", null ],
    [ "node", "structMallocBlockInfo.html#ae4628c67b78874f1569ec84bf8978b91", null ],
    [ "size", "structMallocBlockInfo.html#a7d069f95b78b4e068752abc6277b786b", null ]
];