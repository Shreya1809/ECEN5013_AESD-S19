var bbgled_8h =
[
    [ "GREENLEDOFF", "bbgled_8h.html#ab8e60ea8cf05ab816a7d864f8b94c6b1", null ],
    [ "GREENLEDON", "bbgled_8h.html#a420478e844db6cfc5fe789b4a2d89e50", null ],
    [ "REDLEDOFF", "bbgled_8h.html#a3dd887c9e964d0cfad81ad703bb8738a", null ],
    [ "REDLEDON", "bbgled_8h.html#a8642a79ab7551f839b2fb6693c3518a5", null ],
    [ "greenLed_OnOff", "bbgled_8h.html#ac88dacefab0d1b6e820e4347b09a8a81", null ],
    [ "redLed_OnOff", "bbgled_8h.html#ac4983b0801ad2489c226dd2f056a6fda", null ]
];