var dir_52a1be3d99fad4f5b7f100a041d81233 =
[
    [ "sys.c", "MergeSort_2Sysfile_2sys_8c_source.html", null ],
    [ "syscalls.h", "MergeSort_2Sysfile_2syscalls_8h_source.html", null ]
];