var socket_8c =
[
    [ "kill_socket_thread", "socket_8c.html#a8d7cda36beeab67fa9d5335000d7adf3", null ],
    [ "socket_task", "socket_8c.html#a92f66c7de324d0f99973c1af462cfa3b", null ],
    [ "threads", "socket_8c.html#a3b97289483a2d9585166e53ed6eaeb6a", null ]
];