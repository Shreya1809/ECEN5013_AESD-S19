var dir_13ca857bf2668376211d244307159563 =
[
    [ "fileoperations.c", "Q4_2fileoperations_8c_source.html", null ],
    [ "helperfunctions.c", "Q4_2helperfunctions_8c_source.html", null ],
    [ "helperfunctions.h", "Q4_2helperfunctions_8h_source.html", null ]
];