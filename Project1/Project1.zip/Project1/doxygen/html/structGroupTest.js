var structGroupTest =
[
    [ "number_of_tests", "structGroupTest.html#af72995fabd94fe9ef4da280475d26762", null ],
    [ "setup", "structGroupTest.html#abb15632448009bde536e8187afa2831d", null ],
    [ "teardown", "structGroupTest.html#a59b4a5d3b725b3f625dee8f7fd55cd30", null ],
    [ "tests", "structGroupTest.html#a4365c3917e4b03ac03edbeedc4a24aeb", null ]
];