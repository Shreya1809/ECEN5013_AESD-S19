var socket_8h =
[
    [ "kill_socket_thread", "socket_8h.html#a8d7cda36beeab67fa9d5335000d7adf3", null ],
    [ "socket_task", "socket_8h.html#a92f66c7de324d0f99973c1af462cfa3b", null ]
];