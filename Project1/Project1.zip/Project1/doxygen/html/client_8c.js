var client_8c =
[
    [ "PORT", "client_8c.html#a614217d263be1fb1a5f76e2ff7be19a2", null ],
    [ "main", "client_8c.html#abf9e6b7e6f15df4b525a2e7705ba3089", null ]
];