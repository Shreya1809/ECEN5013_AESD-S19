var structthread__data =
[
    [ "filename", "structthread__data.html#a66b269197cb0c8b0a2af2094f9fb400b", null ],
    [ "linux_id", "structthread__data.html#a17a0e0c53ac893498e261345b2f150e5", null ],
    [ "thread_id", "structthread__data.html#a3711fe61f4229a38fab24e7acba3756b", null ]
];