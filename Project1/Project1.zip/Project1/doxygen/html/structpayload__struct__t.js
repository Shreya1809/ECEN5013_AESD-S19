var structpayload__struct__t =
[
    [ "code", "structpayload__struct__t.html#a14030b281268bad147d54d48d0293278", null ],
    [ "led_status", "structpayload__struct__t.html#a861c3dc0698906ed0285cb739fcd0f27", null ],
    [ "payload", "structpayload__struct__t.html#abc2e8ba68e2ce35eb1501e3c3c0a214f", null ],
    [ "payloadSize", "structpayload__struct__t.html#ab703c50dc3c1b90c62fe811e95c7b009", null ],
    [ "pid", "structpayload__struct__t.html#a5a5c53a1f8ca731a106b2032ab03d856", null ],
    [ "sock_fd", "structpayload__struct__t.html#a6a03483453fab9d73091299d92a2cfdc", null ],
    [ "Timestamp", "structpayload__struct__t.html#a5e0ec8a44c31c07b187d3d01a702bd82", null ]
];