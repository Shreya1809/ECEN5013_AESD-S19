var dir_eb6ab8a6b83e9877b2514e040a9753e3 =
[
    [ "pqClient.c", "pqClient_8c_source.html", null ],
    [ "pqServer.c", "pqServer_8c_source.html", null ]
];