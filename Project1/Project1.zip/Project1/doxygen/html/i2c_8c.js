var i2c_8c =
[
    [ "i2c_close", "i2c_8c.html#a15a1355b5b945d1b2617e205e534e35f", null ],
    [ "i2c_init", "i2c_8c.html#a599b53a348ffd9b2298fcb561417add4", null ],
    [ "i2c_read", "i2c_8c.html#a19cacb29809aba49b97730bdfb7e51f8", null ],
    [ "i2c_write", "i2c_8c.html#a7bbd744d0178497a7b4c74e5933c5a3a", null ],
    [ "i2c_fd", "i2c_8c.html#a1dc55ca7ecf42fa8764eef6c8a9ed885", null ],
    [ "i2c_fname", "i2c_8c.html#a98e196b426edb87702d7ad0a7499dbf3", null ]
];