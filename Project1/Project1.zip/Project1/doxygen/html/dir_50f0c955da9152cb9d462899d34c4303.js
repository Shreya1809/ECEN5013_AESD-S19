var dir_50f0c955da9152cb9d462899d34c4303 =
[
    [ "includes.h", "Homeworks_2HW4_2IPC_2sockets_2includes_8h_source.html", null ],
    [ "socket_client.c", "socket__client_8c_source.html", null ],
    [ "socket_server.c", "socket__server_8c_source.html", null ]
];