var main_8h =
[
    [ "main_struct_t", "structmain__struct__t.html", "structmain__struct__t" ],
    [ "moduleId_t", "main_8h.html#aaa5d4080c07fa6e3f046726990080062", [
      [ "BIST_TASK", "main_8h.html#aaa5d4080c07fa6e3f046726990080062ae7939144206fe5d62a8dc20dc0e81475", null ],
      [ "LOGGER_TASK", "main_8h.html#aaa5d4080c07fa6e3f046726990080062ab79412cb14efd630295a659067c6bf94", null ],
      [ "TEMP_TASK", "main_8h.html#aaa5d4080c07fa6e3f046726990080062a7df5350b39758e0cf6be9bee53fe0876", null ],
      [ "LIGHT_TASK", "main_8h.html#aaa5d4080c07fa6e3f046726990080062a331dc29b924806fff11ac2f97136cf64", null ],
      [ "SOCKET_TASK", "main_8h.html#aaa5d4080c07fa6e3f046726990080062aa7b2f1f5199ad717c1f829a48faac2a3", null ],
      [ "MAIN_TASK", "main_8h.html#aaa5d4080c07fa6e3f046726990080062a22fc72f8859cc4f2b767c5d497dccaca", null ],
      [ "MAX_TASKS", "main_8h.html#aaa5d4080c07fa6e3f046726990080062a194f190e8152f414f69a3c5be2baa0a6", null ]
    ] ],
    [ "moduleIdName", "main_8h.html#ac57dd809293f62560a0b0b98b9c1ffc1", null ],
    [ "thread_flag", "main_8h.html#af35dec9bf93dc50bdb8da5ad7d8450a8", null ]
];