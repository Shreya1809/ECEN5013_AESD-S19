var structlog__struct__t =
[
    [ "level", "structlog__struct__t.html#ab17eaca1fd2ec886aff4db33efa38d29", null ],
    [ "msg", "structlog__struct__t.html#a4df114268b4a76cda98a857935e4309a", null ],
    [ "srcModuleID", "structlog__struct__t.html#a46674802fa9e76e96243f0164d391696", null ],
    [ "timestamp", "structlog__struct__t.html#aa081dbf9f7e8bf4b214fedd40eea688e", null ]
];