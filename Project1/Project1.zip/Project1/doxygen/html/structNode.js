var structNode =
[
    [ "count", "structNode.html#aeff36e03bbb367b048df4e57182cb010", null ],
    [ "list", "structNode.html#ae5cc4d456d668a1d5702089bdcf014fd", null ],
    [ "name", "structNode.html#a059a0ea6f86dce9fd919c08a707b360b", null ]
];