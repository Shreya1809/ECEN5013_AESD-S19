var structi2c__struct__t =
[
    [ "i2c_context", "structi2c__struct__t.html#ac7c93248045c6c2f56438fae7cda1a75", null ],
    [ "status", "structi2c__struct__t.html#a220f85831945900c2b99ae0f1a338944", null ]
];