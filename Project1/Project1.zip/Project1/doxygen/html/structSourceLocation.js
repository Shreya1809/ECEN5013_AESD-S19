var structSourceLocation =
[
    [ "file", "structSourceLocation.html#abe1a3fee04b49b1ea16c433d345d9e3d", null ],
    [ "line", "structSourceLocation.html#a0841da7b3abbe7aca24bb57f071e1042", null ]
];