var light_8h =
[
    [ "GETLUX", "light_8h.html#aa20613ae3290593d8251fd99f4cdee5f", null ],
    [ "APDS9301_checkINTPIN", "light_8h.html#a21ebdd5fb32c58d52dcfe7f4f08445a5", null ],
    [ "APDS9301_IntPinSetup", "light_8h.html#a0e3e495354294ac06a133bb42a58ded4", null ],
    [ "APDS9301_setLightThreshold", "light_8h.html#a111c84e6b2e3a3968a18e4fbd488327f", null ],
    [ "getLight", "light_8h.html#ae749a64e92542af9fe593d9018d64260", null ],
    [ "kill_light_thread", "light_8h.html#ae78695364002a2e4266e084ff7a2a495", null ],
    [ "light_task", "light_8h.html#a173216ebf6f0d4106908c21fcdcddfbf", null ],
    [ "RemoteThresholdValueslight", "light_8h.html#a64fb9b6e666ca43b918e316190751c6c", null ]
];