var dir_ee85af957bb6a02fd50bcbfdc5d98dcd =
[
    [ "sys.c", "BubbleSort_2Sysfile_2sys_8c_source.html", null ],
    [ "syscalls.h", "BubbleSort_2Sysfile_2syscalls_8h_source.html", null ]
];