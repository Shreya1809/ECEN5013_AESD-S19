var searchData=
[
  ['running_20tests',['Running Tests',['../group__cmocka__exec.html',1,'']]],
  ['redled_5fonoff',['redLed_OnOff',['../bbgled_8h.html#ac4983b0801ad2489c226dd2f056a6fda',1,'redLed_OnOff(bool option):&#160;bbgled.c'],['../bbgled_8c.html#ac4983b0801ad2489c226dd2f056a6fda',1,'redLed_OnOff(bool option):&#160;bbgled.c']]],
  ['remotethresholdvalues',['RemoteThresholdValues',['../temp_8h.html#a7beb226afb19a57861973866ecaf5338',1,'RemoteThresholdValues(float flow, float fhigh):&#160;temp.c'],['../temp_8c.html#a7beb226afb19a57861973866ecaf5338',1,'RemoteThresholdValues(float flow, float fhigh):&#160;temp.c']]],
  ['remotethresholdvalueslight',['RemoteThresholdValueslight',['../light_8h.html#a64fb9b6e666ca43b918e316190751c6c',1,'RemoteThresholdValueslight(uint16_t llow, uint16_t lhigh):&#160;light.c'],['../light_8c.html#a64fb9b6e666ca43b918e316190751c6c',1,'RemoteThresholdValueslight(uint16_t llow, uint16_t lhigh):&#160;light.c']]]
];
