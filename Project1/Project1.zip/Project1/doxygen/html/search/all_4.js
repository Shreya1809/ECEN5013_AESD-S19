var searchData=
[
  ['getlight',['getLight',['../light_8h.html#ae749a64e92542af9fe593d9018d64260',1,'getLight(void):&#160;light.c'],['../light_8c.html#ae749a64e92542af9fe593d9018d64260',1,'getLight(void):&#160;light.c']]],
  ['gettemperature',['getTemperature',['../temp_8h.html#ad278c9dd0785311834fbdd25e9ccb08e',1,'getTemperature(temp_unit unit):&#160;temp.c'],['../temp_8c.html#ad278c9dd0785311834fbdd25e9ccb08e',1,'getTemperature(temp_unit unit):&#160;temp.c']]],
  ['gettimemsec',['getTimeMsec',['../logger_8h.html#aacddb84d39f358e65929dc6f4b914de8',1,'getTimeMsec(void):&#160;logger.c'],['../logger_8c.html#a2a8842755f14b8a2ba414132307a8c51',1,'getTimeMsec():&#160;logger.c']]],
  ['greenled_5fonoff',['greenLed_OnOff',['../bbgled_8h.html#ac88dacefab0d1b6e820e4347b09a8a81',1,'greenLed_OnOff(bool option):&#160;bbgled.c'],['../bbgled_8c.html#ac88dacefab0d1b6e820e4347b09a8a81',1,'greenLed_OnOff(bool option):&#160;bbgled.c']]],
  ['group_5ftest_5fsetup',['group_test_setup',['../group__cmocka__exec.html#ga246dbcbb338e4becbfef009b2bb14b78',1,'cmocka.h']]],
  ['group_5ftest_5fteardown',['group_test_teardown',['../group__cmocka__exec.html#ga03159d4169e85cb92bb0eba97cfcf18d',1,'cmocka.h']]],
  ['grouptest',['GroupTest',['../structGroupTest.html',1,'']]]
];
