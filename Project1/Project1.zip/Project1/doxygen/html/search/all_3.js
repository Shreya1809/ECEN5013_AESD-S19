var searchData=
[
  ['dynamic_20memory_20allocation',['Dynamic Memory Allocation',['../group__cmocka__alloc.html',1,'']]],
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]]
];
