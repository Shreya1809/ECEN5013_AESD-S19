/*
 * alert.h
 *
 *  Created on: Apr 10, 2019
 *      Author: Shreya
 */

#ifndef ALERT_H_
#define ALERT_H_
extern uint32_t AlertTaskInit(void);
#endif /* ALERT_H_ */
